<?php

namespace App\Exports;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;

class PartsLotReportExport implements FromView, ShouldAutoSize, WithMultipleSheets
{
    /**
    * @return \Illuminate\Support\Collection
    */
    use Exportable;

    protected $records;
    protected $device_name;

    function __construct($records, $device_name)
    {
        $this->records = $records;
        $this->device_name = $device_name;
    }

    public function sheets(): array
    {
        $sheets = [];

        for ($month = 1; $month <= 12; $month++) {
            $sheets[] = new InvoicesPerMonthSheet($this->year, $month);
        }

        return $sheets;
    }

    // public function view(): View
    // {
    //     $partsLot_records = $this->records;
    //     $device_name = $this->device_name;

    //     return view('exports.partslot', compact('partsLot_records', 'device_name'));
    // }
}
